<?php
$id_telegram = "7306730766";
$id_botTele  = "7288110280:AAGPOZY2ixIw0VnXq-cu6aultKLDQZr3w7A";
?>